+++
categories = ["about"]
comments = false
date = "2016-10-02T22:55:05-04:00"
draft = false
slug = ""
tags = ["about"]
title = "About"

showpagemeta = false
+++

Erlich administers the Hacker Hostel, a tech incubator where Richard, Big Head, Dinesh, and Gilfoyle live and work in exchange for 10 percent of their potential businesses. Erlich clings to his glory days, when he sold aviation start-up Aviato, a move that, at least in his mind, qualifies him to be a svengali lording over other tech nerds. He still drives a car emblazoned with multiple Aviato logos and smokes copious amounts of weed.[1]

In Fiduciary Duties, a drunk Richard makes Erlich a Pied Piper board member, a decision he later regrets.

In Two Days of the Condor, it is revealed that Erlich no longer codes due to carpal tunnel syndrome.

